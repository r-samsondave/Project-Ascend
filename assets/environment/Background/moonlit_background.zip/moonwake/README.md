# MOONWAKE
### Moonlit pixel art backgrounds — Firepious (firepious.com)

The sky above everything else. One moon crossing one night:
The Rise, The Vigil, The Veil, The Wane.

- 1x: 256x144 native (16:9 — integer-scales x5 = 1280x720, x10 = 2560x1440)
- 4x: 1024x576 nearest-neighbor
- Unified night across the set; one light source per scene — the moon,
  rising, high, veiled, waning
- Sky-dominant compositions: these sit behind terrain from any other pack.
- Use as static scenes or scrolling backdrops. Godot 4: Sprite2D/TextureRect
  or ParallaxLayer with motion_mirroring; set texture filter to Nearest.

Disclosure: generated, then judged, then hand-unified, then kept.
Machine-assisted, human-culled. Tagged AI-assisted on itch.

License: see LICENSE.md.

*Firepious — a one-dev cult of the flame making small, strange games with reverence.*
