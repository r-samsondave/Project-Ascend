# MOONWAKE — License

Copyright (c) 2026 Firepious (firepious.com). All rights reserved,
with the following permissions granted:

**You may:**
- Use these images in any project, commercial or non-commercial —
  games, videos, streams, prototypes, anything you're making.
- Modify, crop, recolor, or edit the images to fit your project.
- Ship them inside your game or project without credit.
  (Credit is appreciated, never required: "Backgrounds by Firepious —
  firepious.com")

**You may not:**
- Resell, redistribute, or repackage the images as-is or minimally
  modified — including in other asset packs, image compilations,
  stock libraries, or NFT collections.
- Claim authorship of the original images.

**Disclosure:** these images were machine-generated, then judged,
hand-unified, and kept by a human. This pack is tagged AI-assisted
on itch.io.

Questions: trevor@firepious.com
